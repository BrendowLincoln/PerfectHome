#include "Lista.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Lista* l = inicializa();
	l = insere_inicio(l, 23); /* insere na lista o elemento 23 */
	l = insere_inicio(l, 45); /* insere na lista o elemento 45 */
	l = insere_inicio(l, 56); /* insere na lista o elemento 56 */
	l = insere_inicio(l, 78); /* insere na lista o elemento 78 */
	imprime(l); /* imprimir�: 78 56 45 23 */
	l = retira(l, 78);
	imprime(l); /* imprimir�: 56 45 23 */
	l = retira(l, 45);
	imprime(l); /* imprimir�: 56 23 */
	
	busca_informe (l, 23);
	busca_informe (l, 100);
	
	libera(l);
	system("pause");
	return 0;
}
